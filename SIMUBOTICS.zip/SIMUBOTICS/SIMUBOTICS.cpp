/*
SIMUBOTICS.cpp - Library for SIMUBOTICS v 0.1 Beta  By .SPACE.
*/
#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif
#include "SIMUBOTICS.h"



void SIMUBOTICS::SBini()
{
_i=0;

	while (_i < 1){		
	Serial.print("S");

	while (_i < 1){	
		if (Serial.available() > 0) {
			if (Serial.read() == 'O') {
				Serial.println(";");
				Serial.print("I,0");
				Serial.print(";"); 				
				Serial.println("");
				_i++;
			}
		}
	}
	}
}


void SIMUBOTICS::SBmove(String ComandoVector, int SBciclos)
{
_i=0;

	while (_i < SBciclos){
	Serial.print("S");

	while (_i < 1){	
		if (Serial.available() > 0) {
			if (Serial.read() == 'O') {
				Serial.println(";");
				Serial.print(ComandoVector);
				Serial.print(";"); 				
				Serial.println("");
				_i++;
			}
		}
	}
	}
}

void SIMUBOTICS::SBstop(int SBsciclos)
{
_i=0;

	while (_i < SBsciclos){
	Serial.print("S");

	while (_i < 1){	
		if (Serial.available() > 0) {
			if (Serial.read() == 'O') {
				Serial.println(";");
				Serial.print("N,N,N,N,N,0");
				Serial.print(";"); 				
				Serial.println("");
				_i++;
			}
		}
	}
	}
}