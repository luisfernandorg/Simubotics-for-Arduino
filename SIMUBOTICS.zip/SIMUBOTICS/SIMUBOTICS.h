#ifndef SIMUBOTICS_h
#define SIMUBOTICS_h
#include "Arduino.h"

class SIMUBOTICS
{
   public: void SBini(); void SBmove(String ComandoVector, int SBciclos);
   void SBstop(int SBsciclos);
   private:
   int _i;
};
#endif